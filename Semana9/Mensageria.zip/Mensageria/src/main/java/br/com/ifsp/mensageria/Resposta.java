/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifsp.mensageria;

/**
 *
 * @author renato
 */
public class Resposta implements java.io.Serializable{
    
    public static final int FILE_EXISTS = 1;
    public static final int FILE_NOT_FOUND = 2;
    public static final int CONTENT_AVAILABLE = 3;
    public static final int EOF = 4;
    
    
    private int responseCode;
    private String responseContent;

    /**
     * @return the responseCode
     */
    public int getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode the responseCode to set
     */
    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @return the responseContent
     */
    public String getResponseContent() {
        return responseContent;
    }

    /**
     * @param responseContent the responseContent to set
     */
    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }
    
}
