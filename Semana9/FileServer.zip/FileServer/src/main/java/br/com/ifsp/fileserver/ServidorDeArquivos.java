/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifsp.fileserver;

import br.com.ifsp.mensageria.Requisicao;
import br.com.ifsp.mensageria.Resposta;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author renat
 */
public class ServidorDeArquivos {

    public static void main(String[] args) {

        ServerSocket serverSocket;
        Socket cliente;
        Resposta rep;

        try {
            serverSocket = new ServerSocket(40000);
            System.out.println("DEBUG - Server started at 40000");

            //aplicação dedicada
            while (true) {
                cliente = serverSocket.accept(); //conectou
                ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());

                Requisicao req = (Requisicao) in.readObject();
                System.out.println("DEBUG - REQ: " + req.getMessageType() + "/" + req.getMessageContent());

                if (req.getMessageType() == Requisicao.FILENAME_REQUEST) {
                    //abri o arquivo que veio como conteúdo da requisição
                    File f = new File(req.getMessageContent());
                    rep = new Resposta();
                    if (f.exists()) {
                        rep.setResponseCode(Resposta.FILE_EXISTS);
                        out.writeObject(rep);

                        //abre o arquivo em modo leitura
                        FileReader fr = new FileReader(f);
                        BufferedReader br = new BufferedReader(fr);// elemento para fazer as leituras
                        String linha = null;

                        do {

                            req = (Requisicao) in.readObject(); // aguardo o pedido do cliente
                            
                            System.out.println(">>>>>> Request content");
                            //se o cliente solicitar um conteúdo de arquivo
                            if (req.getMessageType() == Requisicao.FILECONTENT_REQUEST) {

                                linha = br.readLine();
                                rep = new Resposta();
                                
                                //se houver conteúdo
                                if (linha != null) {

                                    rep.setResponseCode(Resposta.CONTENT_AVAILABLE);
                                    rep.setResponseContent(linha);
                                }else{ //cheguei no final do arquivo
                                    rep.setResponseCode(Resposta.EOF);
                                }
                                out.writeObject(rep);
                                System.out.println(">>>>>> Content sent");
                            }

                        } while (linha != null);
                        fr.close();
                        

                    } else {
                        rep.setResponseCode(Resposta.FILE_NOT_FOUND);
                        out.writeObject(rep);
                    }

                }
                in.close();
                out.close();
                cliente.close();
            }

        } catch (Exception e) {
            System.out.println("Deu pau no servidor");
            e.printStackTrace();

        }

    }

}
