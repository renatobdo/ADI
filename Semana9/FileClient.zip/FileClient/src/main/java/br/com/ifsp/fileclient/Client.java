/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifsp.fileclient;

import br.com.ifsp.mensageria.Requisicao;
import br.com.ifsp.mensageria.Resposta;
import java.io.File;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author renat
 */
public class Client {
    public static void main(String[] args){
        Socket socket;
        Scanner teclado = new Scanner(System.in);
        try {
            socket = new Socket("localhost", 40000);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            
            System.out.println("Client: digite o nome do arquivo ");
            String fileName = teclado.nextLine();
            Requisicao req = new Requisicao();
            req.setMessageType(Requisicao.FILENAME_REQUEST);
            req.setMessageContent(fileName);
            
            //envio da requisicao
            out.writeObject(req);
            
            //espera a resposta
            Resposta rep = (Resposta)in.readObject();
            if(rep.getResponseCode() == Resposta.FILE_EXISTS){
                System.out.println("Sucesso - Arquivo existe no servidor... pronto para iniciar download");
                
                //Download do arquivo
                
                //passo 1 crio meu arquivo localmente em mode escrita
                FileWriter fw = new FileWriter(new File(fileName));
                do{
                    req = new Requisicao();
                    req.setMessageType(Requisicao.FILECONTENT_REQUEST);
                    
                    
                    //enviei a requisicao
                    out.writeObject(req);                    
                    System.out.println(">>>>> Download"+fileName+" enviando requisicao");
                    
                    rep = (Resposta)in.readObject();
                    if(rep.getResponseCode() == Resposta.CONTENT_AVAILABLE){
                        System.out.println("Received package");
                        fw.write(rep.getResponseContent()+"\n");
                    }
                    
                }while(rep.getResponseCode() != Resposta.EOF);
                fw.close();
                
                
            }else if (rep.getResponseCode() == Resposta.FILE_NOT_FOUND){
                System.out.println("Erro - Arquivo não existe no servidor");
            }
            
            in.close();
            out.close();
            socket.close();
            
        } catch (Exception e) {
            System.out.println("Erro no cliente");
            e.printStackTrace();
        }
    }
}
