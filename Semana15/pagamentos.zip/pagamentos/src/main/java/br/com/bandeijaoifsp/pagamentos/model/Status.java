package br.com.bandeijaoifsp.pagamentos.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CANCELADO

}
