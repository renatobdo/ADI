package br.com.bandeijaoifsp.pagamentos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bandeijaoifsp.pagamentos.model.Pagamento;

public interface PagamentoRepository extends JpaRepository<Pagamento, Long> {
}
