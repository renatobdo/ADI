package cluster.management;
//Integra o LeaderElection com o serviceRegistry
public interface OnElectionCallback {

    void onElectedToBeLeader();

    void onWorker();
}
