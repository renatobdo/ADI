package br.com.ifsp.carros;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class ExceptionConfig {
	
	@ExceptionHandler(value = {EmptyResultDataAccessException.class})
	public ResponseEntity errorNotFound(Exception ex) {
		return ResponseEntity.notFound().build();
		
	}

}
