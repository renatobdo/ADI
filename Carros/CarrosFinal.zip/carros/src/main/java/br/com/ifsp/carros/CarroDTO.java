package br.com.ifsp.carros;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.modelmapper.ModelMapper;

import lombok.Data;

@Entity
@Data
public class CarroDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nome;
	private String tipo;
	
	
	/*  public CarroDTO(Carro c) {
		  this.id = c.getId();
		  this.nome = c.getNome();
		  this.tipo = c.getTipo();
	  }
	  public CarroDTO(Long id,String nome) {}
	  */
	  public static CarroDTO create(Carro c) {
		  ModelMapper modelMapper = new ModelMapper();
		  CarroDTO carroDTO = modelMapper.map(c, CarroDTO.class);
		  return carroDTO;
	  }
	
}
