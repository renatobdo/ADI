package br.com.alurafood.pagamentos.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CONFIRMADO_SEM_INTEGRACAO,
    CANCELADO

}
