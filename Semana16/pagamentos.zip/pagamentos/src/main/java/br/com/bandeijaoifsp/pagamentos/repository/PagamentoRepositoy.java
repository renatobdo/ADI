package br.com.bandeijaoifsp.pagamentos.repository;

import br.com.bandeijaoifsp.pagamentos.model.Pagamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagamentoRepositoy extends JpaRepository<Pagamento, Long> {
}
